This program was written in python. This program shows communication between client and server. Where one is a broadcast UDP packet

Author: Natnael Teferi
Date: 02/07/2020
Python 2: no
Python 3: yes
